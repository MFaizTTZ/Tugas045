# web-security-labs-faiz_c2c-023045
Educational repo for UTS - Keamanan Data dan Informasi (Praktikum)

Structure:
- index.php (menu)
- vulnerable/ (intentionally insecure modules)
- secure/ (mitigated secure modules)
- db.sql (create DB + sample users)
- README contains instructions

How to run (XAMPP):
1. Copy folder to C:\xampp\htdocs\web-security-labs-nama_nim (or /opt/lampp/htdocs/)
2. Start Apache & MySQL
3. Import db.sql into phpMyAdmin or run the SQL
4. Visit http://localhost/web-security-labs-faiz_c2c023045/

Danger:
- The vulnerable/ code is intentionally insecure for learning and must never be deployed to production.
