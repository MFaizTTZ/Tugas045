<?php
// Broken access control - naive profile display by id without auth
$id = $_GET['id'] ?? '';
?>
<!doctype html><html><body>
<h2>Profile (Vulnerable)</h2>
<?php
if ($id === '') {
    echo '<p>Provide ?id=USER_ID in URL, e.g. profile_vul.php?id=1</p>';
} else {
    // For demo, simply show the id. In real app this would fetch DB details.
    echo "<p>Displaying profile for user id: " . htmlspecialchars($id) . "</p>";
    echo "<p>(No authorization check performed)</p>";
}
?>
<a href="../index.php">Back</a>
</body></html>
