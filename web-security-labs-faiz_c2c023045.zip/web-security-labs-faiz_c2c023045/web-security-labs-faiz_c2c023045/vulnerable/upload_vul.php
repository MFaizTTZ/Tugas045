<?php
// Vulnerable file upload: saves original filename into webroot (dangerous)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $t = $_FILES['file']['tmp_name'];
    $n = basename($_FILES['file']['name']);
    move_uploaded_file($t, __DIR__ . '/uploads/' . $n);
    echo "<p>Uploaded as: uploads/$n</p>";
}
?>
<!doctype html><html><body>
<h2>File Upload (Vulnerable)</h2>
<form method="post" enctype="multipart/form-data">
<input type="file" name="file"><br>
<input type="submit" value="Upload">
</form>
<p>Try uploading a .php file (this will be saved and may be executable).</p>
<a href="../index.php">Back</a>
</body></html>
