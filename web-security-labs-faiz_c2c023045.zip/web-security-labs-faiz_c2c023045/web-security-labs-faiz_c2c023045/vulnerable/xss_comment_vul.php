<?php
// Vulnerable XSS comment example - echoes raw input
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $c = $_POST['comment'] ?? '';
    echo "<h3>Recent comment (vulnerable)</h3>";
    echo "<div>$c</div>";
}
?>
<!doctype html><html><body>
<h2>XSS Comment (Vulnerable)</h2>
<form method="post">
<textarea name="comment" rows="4" cols="50"></textarea><br>
<input type="submit" value="Post">
</form>
<p>Try posting: <code>&lt;script&gt;alert('XSS')&lt;/script&gt;</code></p>
<a href="../index.php">Back</a>
</body></html>
