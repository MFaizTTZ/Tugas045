<?php
// Vulnerable SQL login - DO NOT USE IN PRODUCTION
$conn = new mysqli('localhost', 'root', '', 'web_security');
if ($conn->connect_error) die('DB error');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = $_POST['username'] ?? '';
    $p = $_POST['password'] ?? '';
    // vulnerable concatenation
    $q = "SELECT * FROM users WHERE username='$u' AND password='$p'";
    $res = $conn->query($q);
    if ($res && $res->num_rows>0) {
        echo '<p style="color:green">Login berhasil (vulnerable)</p>';
    } else {
        echo '<p style="color:red">Gagal login</p>';
    }
}
?>
<!doctype html><html><body>
<h2>SQL Login (Vulnerable)</h2>
<form method="post">
Username: <input name="username"><br>
Password: <input name="password"><br>
<input type="submit" value="Login">
</form>
<p>Try: username: <code>' OR '1'='1</code> and any password to bypass.</p>
<a href="../index.php">Back</a>
</body></html>
