-- db.sql - create database and sample user
CREATE DATABASE IF NOT EXISTS web_security CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE web_security;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
);

-- Insert sample users
-- Vulnerable examples may store plaintext (for demonstration only)
INSERT INTO users (username, password) VALUES ('alice', 'alicepass'), ('bob', 'bobpass');

-- Secure example instructions:
-- Use PHP password_hash to create hashed password; example:
-- INSERT INTO users (username, password) VALUES ('admin', '<bcrypt-hash>');
