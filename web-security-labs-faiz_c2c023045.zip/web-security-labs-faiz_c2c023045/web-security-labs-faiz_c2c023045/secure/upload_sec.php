<?php
// Secure upload: whitelist extensions, rename, store outside webroot recommended
$upload_dir = __DIR__ . '/uploads/';
if (!is_dir($upload_dir)) mkdir($upload_dir, 0755);
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $tmp = $_FILES['file']['tmp_name'];
    $orig = $_FILES['file']['name'];
    $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
    $allowed = ['png','jpg','jpeg','pdf','txt'];
    if (!in_array($ext, $allowed)) {
        echo "<p style='color:red'>Ekstensi tidak diizinkan.</p>";
    } elseif ($_FILES['file']['size'] > 5*1024*1024) {
        echo "<p style='color:red'>File terlalu besar (max 5MB).</p>";
    } else {
        $new = uniqid('f_', true) . '.' . $ext;
        move_uploaded_file($tmp, $upload_dir . $new);
        echo "<p>Upload sukses. Stored as: uploads/$new</p>";
    }
}
?>
<!doctype html><html><body>
<h2>File Upload (Secure)</h2>
<form method="post" enctype="multipart/form-data">
<input type="file" name="file"><br>
<input type="submit" value="Upload">
</form>
<p>Secure version validates extension, size and renames file.</p>
<a href="../index.php">Back</a>
</body></html>
