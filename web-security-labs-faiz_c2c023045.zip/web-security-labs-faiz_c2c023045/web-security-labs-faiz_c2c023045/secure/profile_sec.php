<?php
// Secure profile: use session-based auth and ownership check
session_start();
// Simple demo login (do not use in production): set ?login=alice to simulate login
if (isset($_GET['login'])) {
    $_SESSION['user'] = $_GET['login'];
    // user_id mapping for demo
    $_SESSION['user_id'] = ($_GET['login'] === 'alice') ? 1 : 2;
    echo "<p>Logged in as ".$_SESSION['user']."</p>";
}
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
?>
<!doctype html><html><body>
<h2>Profile (Secure)</h2>
<?php
if (!isset($_SESSION['user'])) {
    echo '<p>You are not logged in. Simulate login by adding ?login=alice or ?login=bob to the URL.</p>';
    echo '<a href="?login=alice">Login as alice</a> | <a href="?login=bob">Login as bob</a>';
} else {
    if ($id === 0) {
        echo '<p>Provide ?id=USER_ID in URL to view profile (e.g. ?id=1)</p>';
    } else {
        // check ownership
        if ($id !== $_SESSION['user_id']) {
            http_response_code(403);
            echo '<p style="color:red">Akses ditolak: Anda tidak berhak melihat profile ini.</p>';
        } else {
            echo "<p>Welcome ".$_SESSION['user'].", this is your profile (id=".$id.").</p>";
        }
    }
}
?>
<a href="../index.php">Back</a>
</body></html>
