<?php
// secure/auth.php - start session and create a token + uuid for demo
if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['token'])) {
    $_SESSION['token'] = bin2hex(random_bytes(16));
    $_SESSION['uuid'] = uniqid('u_', true);
}
?>