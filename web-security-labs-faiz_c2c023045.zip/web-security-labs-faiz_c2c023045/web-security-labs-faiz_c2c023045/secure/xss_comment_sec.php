<?php
// Secure XSS example: escape output with htmlspecialchars
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $c = $_POST['comment'] ?? '';
    echo "<h3>Recent comment (secure)</h3>";
    echo "<div>" . htmlspecialchars($c, ENT_QUOTES, 'UTF-8') . "</div>";
}
?>
<!doctype html><html><body>
<h2>XSS Comment (Secure)</h2>
<form method="post">
<textarea name="comment" rows="4" cols="50"></textarea><br>
<input type="submit" value="Post">
</form>
<p>Secure version escapes output.</p>
<a href="../index.php">Back</a>
</body></html>
