<?php
// Secure login using prepared statements and password_verify
$conn = new mysqli('localhost', 'root', '', 'web_security');
if ($conn->connect_error) die('DB error');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $u = $_POST['username'] ?? '';
    $p = $_POST['password'] ?? '';
    $stmt = $conn->prepare('SELECT password FROM users WHERE username=?');
    $stmt->bind_param('s', $u);
    $stmt->execute();
    $stmt->bind_result($hash);
    if ($stmt->fetch()) {
        // If DB has plaintext passwords (from sample), support that for demo by checking raw equality first.
        if (password_verify($p, $hash)) {
            echo '<p style="color:green">Login berhasil (secure)</p>';
        } elseif ($p === $hash) {
            // fallback for demo DB with plaintext - in real world remove this
            echo '<p style="color:orange">Login berhasil (fallback plaintext) - please migrate to hashed passwords</p>';
        } else {
            echo '<p style="color:red">Gagal login</p>';
        }
    } else {
        echo '<p style="color:red">Gagal login</p>';
    }
    $stmt->close();
}
?>
<!doctype html><html><body>
<h2>SQL Login (Secure)</h2>
<form method="post">
Username: <input name="username"><br>
Password: <input name="password"><br>
<input type="submit" value="Login">
</form>
<p>Secure version uses prepared statements and password_hash verification.</p>
<a href="../index.php">Back</a>
</body></html>
