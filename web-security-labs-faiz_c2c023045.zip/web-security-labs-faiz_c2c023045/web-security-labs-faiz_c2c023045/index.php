<?php
// index.php - menu utama
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Web Security Labs - web-security-labs-faiz_c2c023045</title>
  <style>body{font-family:system-ui,Segoe UI,Roboto,Arial;padding:20px;} a{display:block;margin:6px 0;}</style>
</head>
<body>
  <h1>Web Security Labs (vulnerable & secure)</h1>
  <p>Folder <strong>vulnerable/</strong> contains intentionally vulnerable examples. <strong>secure/</strong> contains mitigated versions.</p>
  <h2>SQL Injection</h2>
  <a href="vulnerable/sql_login_vul.php">SQL Login (Vulnerable)</a>
  <a href="secure/sql_login_sec.php">SQL Login (Secure)</a>

  <h2>XSS</h2>
  <a href="vulnerable/xss_comment_vul.php">XSS Comment (Vulnerable)</a>
  <a href="secure/xss_comment_sec.php">XSS Comment (Secure)</a>

  <h2>Upload</h2>
  <a href="vulnerable/upload_vul.php">File Upload (Vulnerable)</a>
  <a href="secure/upload_sec.php">File Upload (Secure)</a>

  <h2>Profile / Broken Access Control</h2>
  <a href="vulnerable/profile_vul.php">Profile (Vulnerable)</a>
  <a href="secure/profile_sec.php">Profile (Secure)</a>

  <h2>Notes</h2>
  <ul>
    <li>Place this folder in your XAMPP <code>htdocs</code> directory (e.g. C:\xampp\htdocs\).</li>
    <li>Import <code>db.sql</code> into MySQL (phpMyAdmin) or create database <code>web_security</code> and table <code>users</code>.</li>
  </ul>
</body>
</html>
