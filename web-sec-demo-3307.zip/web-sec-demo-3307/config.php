<?php
// config.php — use when MySQL is on port 3307

$DB_HOST = '127.0.0.1';
$DB_PORT = '3307';          // <<< ensure this is 3307
$DB_NAME = 'websec_demo';
$DB_USER = 'root';
$DB_PASS = '';

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
];

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;port=$DB_PORT;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        $options
    );
} catch (PDOException $e) {
    echo "<h3 style='color:red;'>DB Connection failed:</h3> " . htmlspecialchars($e->getMessage());
    exit;
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}
function current_user_id() {
    return $_SESSION['user_id'] ?? null;
}
function current_user_role() {
    return $_SESSION['user_role'] ?? null;
}
?>