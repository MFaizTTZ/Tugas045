WebSec Demo (configured for MySQL port 3307)

- Place the 'public' folder into your webroot (e.g. C:\xampp\htdocs\web-sec-demo\public)
- Place config.php one level above public (or adjust require paths)
- Import init_db.sql into your MySQL (port 3307): mysql -u root -p --port=3307 < init_db.sql
- Ensure uploads/ is writable and .htaccess is present to block PHP execution
- Open http://localhost/web-sec-demo/public/ in browser
