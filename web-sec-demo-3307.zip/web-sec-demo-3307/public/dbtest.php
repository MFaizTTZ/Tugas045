<?php
require_once __DIR__ . '/../config.php';
try {
    $pdo->query("SELECT 1");
    echo "✅ DB OK — connected to {$DB_NAME} on port {$DB_PORT}";
} catch (Exception $e) {
    echo "❌ DB Connection error: " . htmlspecialchars($e->getMessage());
}
?>