<?php
require_once __DIR__ . '/../config.php';
?>
<!doctype html><html><head><meta charset="utf-8"><title>SQL Injection</title></head><body>
<h2>SQL Injection — Vulnerable</h2>
<p>This is a placeholder page for SQLi. Use full project files for complete lab.</p>
<p><a href="index.php">Back</a></p>
</body></html>
