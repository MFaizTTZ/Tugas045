<?php
require_once __DIR__ . '/../config.php';
?>
<!doctype html><html><head><meta charset="utf-8"><title>Broken Access Control</title></head><body>
<h2>Broken Access Control — Safe</h2>
<p>This is a placeholder safe version for BAC.</p>
<p><a href="index.php">Back</a></p>
</body></html>
