<?php
require_once __DIR__ . '/../config.php';
?>
<!doctype html><html><head><meta charset="utf-8"><title>File Upload</title></head><body>
<h2>File Upload — Vulnerable</h2>
<p>This is a placeholder page for File Upload. Use full project files for complete lab.</p>
<p><a href="index.php">Back</a></p>
</body></html>
