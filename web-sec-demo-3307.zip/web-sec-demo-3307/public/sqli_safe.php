<?php
require_once __DIR__ . '/../config.php';
?>
<!doctype html><html><head><meta charset="utf-8"><title>SQL Injection</title></head><body>
<h2>SQL Injection — Safe</h2>
<p>This is a placeholder safe version for SQLi.</p>
<p><a href="index.php">Back</a></p>
</body></html>
