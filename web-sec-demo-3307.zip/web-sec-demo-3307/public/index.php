<?php
require_once __DIR__ . '/../config.php';
?>
<!doctype html><html><head><meta charset="utf-8"><title>WebSec Demo</title>
<link rel="stylesheet" href="assets/styles.css">
</head><body>
<nav>
  <a href="index.php">Home</a>
  <a href="sqli_vul.php">SQLi (vul)</a>
  <a href="sqli_safe.php">SQLi (safe)</a>
  <a href="xss_vul.php">XSS (vul)</a>
  <a href="xss_safe.php">XSS (safe)</a>
  <a href="upload_vul.php">Upload (vul)</a>
  <a href="upload_safe.php">Upload (safe)</a>
  <a href="bac_vul.php">BAC (vul)</a>
  <a href="bac_safe.php">BAC (safe)</a>
  <a href="dbtest.php">DB Test</a>
</nav>

<h1>Web Security Demo (port 3307)</h1>
<p>Disclaimer: local lab only.</p>
</body></html>
